window.onload = function()
{
    var httpRequest;
    var emailAddress = document.getElementById("emailAddress");
    var resultText = document.getElementById("resultEmail");
}