<?php
	$cart_string = $_POST['cartString'];
	echo("true");




?>